package com.clubdeportivo2.servicioreservas.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clubdeportivo2.servicioreservas.Client.CanchaClient;
import com.clubdeportivo2.servicioreservas.model.Reserva;
import com.clubdeportivo2.servicioreservas.repository.ReservaRepository;
import com.clubdeportivo2.servicioreservas.model.dto.CanchaDTO; 

import java.util.List;

@Service
public class ReservaServicesImpl implements ReservaServices {

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private CanchaClient canchaClient; 
    @Override
    public List<Reserva> listarReservas() {
        return reservaRepository.findAll();
    }

    @Override
    public Reserva crearReserva(Reserva reserva) {
        
        try {
            CanchaDTO cancha = canchaClient.obtenerCanchaPorId(reserva.getCanchaId());

            if (cancha != null && cancha.getId() != null) {
                return reservaRepository.save(reserva);
            } else {
                
                throw new RuntimeException("La cancha con ID " + reserva.getCanchaId() + " no existe.");
            }
        } catch (Exception e) {
            
            throw new RuntimeException("Error de comunicación con el servicio de Canchas: " + e.getMessage());
        }
    }

    @Override
    public List<Reserva> buscarReservasPorCancha(Long canchaId) {
        return reservaRepository.findByCanchaId(canchaId);
    }
}