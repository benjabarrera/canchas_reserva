package com.clubdeportivo2.servicioreservas.model.dto;

public class CanchaDTO {
    private Long id;
    private String nombre;
    private String tipo;

    // Constructor vacío
    public CanchaDTO() {
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}