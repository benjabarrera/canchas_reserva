package com.clubdeportivo2.servicioreservas.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.clubdeportivo2.servicioreservas.model.dto.CanchaDTO;

// Esta anotación le dice a Spring que este es el cliente para el otro microservicio
@FeignClient(name = "servicio-canchas", url = "http://localhost:8082")
public interface CanchaClient {

    // Este método debe coincidir con el GetMapping que tengas en el controlador de Canchas
    @GetMapping("/api/canchas/{id}")
    CanchaDTO obtenerCanchaPorId(@PathVariable("id") Long id);
}